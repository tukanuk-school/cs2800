# readme.md

## used assets from Asset Store

- Office Supplies Low Poly by Sten Ulfsson
- Yughues Free Rock by Nobiax / Yughues 

## Instructions

1. for full experience, start from _Scene_4.
2. Game should work at all screen resolutions above 1280x720 with canvas layout adjusting appropriately 
3. Follow onscreen instructions for player specific keys. 
4. Game is designed for two players to play and not give away the key they pressed.
5. Try getting the same answer many times.

## TODO

- add animation to objects for each turn (ie rock smashes on scissor)